create or replace Package Body sp_update_email_api as
/* $Header: peperapi.pkb 120.4.12010000.3 2008/09/08 14:54:17 sidsaxen ship $ */
--
-- Package Variables
--
g_package  varchar2(33) := 'sp_update_email_api';
g_debug boolean := hr_utility.debug_enabled;
--
-- ----------------------------------------------------------------------------
-- |---------------------------< update_person >------------------------------|
-- ----------------------------------------------------------------------------
--
procedure update_person (
    p_effective_date            in date,
    p_datetrack_update_mode     in varchar2,
    p_person_id                 in number,
    p_email_address             in varchar2,
    p_object_version_number     in out number,
    p_employee_number           in out varchar2,
    p_effective_start_date      out date,
    p_effective_end_date        out date,
    p_full_name                 out varchar2,
    p_comment_id                out number,
    p_name_combination_warning  out boolean,
    p_assign_payroll_warning    out boolean,
    p_orig_hire_warning         out boolean
)
is
  l_object_version_number     number;
  l_employee_number           varchar2(4000);
  l_effective_start_date      date;
  l_effective_end_date        date;
  l_full_name                 varchar2(4000);
  l_comment_id                number;
  l_name_combination_warning  boolean;
  l_assign_payroll_warning    boolean;
  l_orig_hire_warning         boolean;  
begin
  l_object_version_number := p_object_version_number;

  hr_person_api.update_person (
    p_effective_date            => p_effective_date,
    p_datetrack_update_mode     => p_datetrack_update_mode,
    p_person_id                 => p_person_id,
    p_email_address             => p_email_address,
    p_object_version_number     => l_object_version_number,
    p_employee_number           => p_employee_number,
    p_effective_start_date      => l_effective_start_date,
    p_effective_end_date        => l_effective_end_date,
    p_full_name                 => l_full_name,
    p_comment_id                => l_comment_id,
    p_name_combination_warning  => l_name_combination_warning,
    p_assign_payroll_warning    => l_assign_payroll_warning,
    p_orig_hire_warning         => l_orig_hire_warning
  );
end update_person;

end sp_update_email_api;
