create or replace Package sp_update_email_api as

procedure update_person (
    p_effective_date            in date,
    p_datetrack_update_mode     in varchar2,
    p_person_id                 in number,
    p_email_address             in varchar2,
    p_object_version_number     in out number,
    p_employee_number           in out varchar2,
    p_effective_start_date      out date,
    p_effective_end_date        out date,
    p_full_name                 out varchar2,
    p_comment_id                out number,
    p_name_combination_warning  out boolean,
    p_assign_payroll_warning    out boolean,
    p_orig_hire_warning         out boolean
);

end sp_update_email_api;
