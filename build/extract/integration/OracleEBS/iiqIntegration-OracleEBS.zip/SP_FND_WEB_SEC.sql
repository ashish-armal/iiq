create or replace PACKAGE SP_FND_WEB_SEC AS

function validate_login( i_username in varchar2, i_password in varchar2 ) 
 return VARCHAR2;
	
END SP_FND_WEB_SEC;